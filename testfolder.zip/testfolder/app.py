from flask import Flask, Response,render_template
import pyaudio

app = Flask(__name__)


FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
CHUNK = 8192
RECORD_SECONDS = 5


audio1 = pyaudio.PyAudio()

def to_bytes(n, length, endianess ='big'):
    h = '%x' % n
    s = ('0'*(len(h) % 2) + h).zfill(length*2).decode('hex')
    return s if endianess == 'big' else s[::-1]


def genHeader(sampleRate, bitsPerSample, channels):
    datasize = 2000*10**6
    #o = bytes("RIFF",encoding=['ascii'])                                               # (4byte) Marks file as RIFF
    o = str('RIFF').encode('ascii')
    #o += (datasize + 36).to_bytes(4,'little')                               # (4byte) File size in bytes excluding this and RIFF marker
    o += to_bytes((datasize + 36),4,'little')
    #o += bytes("WAVE",'ascii')                                              # (4byte) File type
    o += str('WAVE').encode('ascii')
    #o += bytes("fmt ",'ascii')                                              # (4byte) Format Chunk Marker
    o += str("fmt ").encode('ascii')
    #o += (16).to_bytes(4,'little')                                          # (4byte) Length of above format data
    o += to_bytes(16,4,'little')
    #o += (1).to_bytes(2,'little')                                           # (2byte) Format type (1 - PCM)
    o += to_bytes(1, 2, 'little')
    #o += (channels).to_bytes(2,'little')                                    # (2byte)
    o += to_bytes(channels,2,'little')
    #o += (sampleRate).to_bytes(4,'little')                                  # (4byte)
    o += to_bytes(sampleRate,4,'little')
    #o += (sampleRate * channels * bitsPerSample // 8).to_bytes(4,'little')  # (4byte)
    o += to_bytes((sampleRate * channels * bitsPerSample // 8),4,'little')
    #o += (channels * bitsPerSample // 8).to_bytes(2,'little')               # (2byte)
    o += to_bytes((channels * bitsPerSample //8),2, 'little')
    #o += (bitsPerSample).to_bytes(2,'little')                               # (2byte)
    o += to_bytes(bitsPerSample, 2, 'little')
    #o += bytes("data",'ascii')                                              # (4byte) Data Chunk Marker
    o += str('data').encode('ascii')
    #o += (datasize).to_bytes(4,'little')                                    # (4byte) Data size in bytes
    o += to_bytes(datasize, 4, 'little')
    return o

@app.route('/audio')
def audio():
    # start Recording
    def sound():

        CHUNK = 8192
        sampleRate = 44100
        bitsPerSample = 16
        channels = 1
        wav_header = genHeader(sampleRate, bitsPerSample, channels)

        stream = audio1.open(format=FORMAT, channels=CHANNELS,
                        rate=RATE, input=True,input_device_index=2,
                        frames_per_buffer=CHUNK)
        print("recording...")
        #frames = []
        first_run = True
        while True:
           if first_run:
               data = wav_header + stream.read(CHUNK)
               first_run = False
           else:
               data = stream.read(CHUNK)
           yield(data)

    return Response(sound())

@app.route('/')
def index():
    """Video streaming home page."""
    return render_template('index.html')


if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True, threaded=True,port=5000)
